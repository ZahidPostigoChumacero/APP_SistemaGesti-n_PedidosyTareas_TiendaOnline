package servicio;

import java.util.ArrayList;
import java.util.List;
import modelo.Usuario;

/**
 *
 * @author Alvaro Zahid Postigo Chumacero
 */
//Servicio para el Login
public class LoginServicio {

    private final List<Usuario> usuarios;

    //Constructor
    public LoginServicio() {
        usuarios = new ArrayList<>();
        
        usuarios.add(new Usuario("admin", "admin", "ADMIN"));
        
        usuarios.add(new Usuario("usuario", "1234", "USUARIO"));
    }

    
    //Valida las credenciales de inicio de sesión.
    public Usuario validar(String user, String pass) {
        if (user == null || pass == null) {
            return null;
        }
        for (Usuario u : usuarios) {
            if (u.getUsuario().equalsIgnoreCase(user)
                    && u.getContrasena().equals(pass)) {
                return u;
            }
        }
        return null;
    }
}